from langchain_openai import ChatOpenAI

def chat_gpt(model_name="gpt-4o", temperature=0.01):
    model = ChatOpenAI(model=model_name, temperature=temperature)
    return model
